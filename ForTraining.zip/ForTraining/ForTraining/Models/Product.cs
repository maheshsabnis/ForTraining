﻿using System;
using System.Collections.Generic;

namespace ForTraining.Models;

public partial class Product : EntityBase
{
    public int ProductRecordId { get; set; }

    public string ProductId { get; set; } = null!;

    public string ProductName { get; set; } = null!;

    public string Description { get; set; } = null!;

    public int Price { get; set; }

    public string CategoryId { get; set; } = null!;

    public virtual Category Category { get; set; } = null!;
}
