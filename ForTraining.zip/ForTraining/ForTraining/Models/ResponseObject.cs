﻿namespace ForTraining.Models
{
    public class ResponseObject<TModel> where TModel:class
    {
        public IEnumerable<TModel> Records { get; set; } = null!;
        public TModel Record { get; set; } = null!;
        public string Message { get; set; } = null!;
    }
}
