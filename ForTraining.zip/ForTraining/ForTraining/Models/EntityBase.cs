﻿namespace ForTraining.Models
{
    public abstract class EntityBase
    {
    }
}
