﻿using ForTraining.Models;

namespace ForTraining.Services
{
    public interface IServies<TModel, in TPk> where TModel:EntityBase
    {
        Task<ResponseObject<TModel>> GetAsync();
        Task<ResponseObject<TModel>> GetAsync(TPk id);
        Task<ResponseObject<TModel>> CreateAsync(TModel entity);
        Task<ResponseObject<TModel>> UpdateAsync(TModel entity);
        Task<ResponseObject<TModel>> DeleteAsync(TModel entity);
    }
}
