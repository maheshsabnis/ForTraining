using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ForTraining.Models;
using Microsoft.EntityFrameworkCore;

namespace ForTraining.Services
{
    public class GenericService<TModel,  TPk> : IServies<TModel, TPk> where TModel : EntityBase
    {
        private readonly AppDbContext _context;

        public GenericService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<ResponseObject<TModel>> GetAsync()
        {
            try
            {
                var entities = await _context.Set<TModel>().ToListAsync();
                return new ResponseObject<TModel>
                {
                    Records = entities,
                    Message = "Success"
                };
            }
            catch (Exception ex)
            {
                return new ResponseObject<TModel>
                {
                    Message = $"Error: {ex.Message}"
                };
            }
        }

        public async Task<ResponseObject<TModel>> GetAsync(TPk id)
        {
            try
            {
                var entity = await _context.Set<TModel>().FindAsync(id);
                if (entity == null)
                {
                    return new ResponseObject<TModel>
                    {
                        Record = entity,
                        Message = "Success"
                    };
                }

                return new ResponseObject<TModel>
                {
                    Message = $"Success:"
                };
            }
            catch (Exception ex)
            {
                return new ResponseObject<TModel>
                {
                    Message = $"Error: {ex.Message}"
                };
            }
        }

        public async Task<ResponseObject<TModel>> CreateAsync(TModel entity)
        {
            try
            {
                var result = await _context.Set<TModel>().AddAsync(entity);
                await _context.SaveChangesAsync();

                return new ResponseObject<TModel>
                {
                    Record = result.Entity,
                    Message = $"Success:"
                };
            }
            catch (Exception ex)
            {
                return new ResponseObject<TModel>
                {
                    Message = $"Error: {ex.Message}"
                };
            }
        }

        public async Task<ResponseObject<TModel>> UpdateAsync(TModel entity)
        {
            try
            {
                _context.Set<TModel>().Update(entity);
                await _context.SaveChangesAsync();

                return new ResponseObject<TModel>
                {
                    Record = entity,
                    Message = $"Success: Update"
                };
            }
            catch (Exception ex)
            {
                return new ResponseObject<TModel>
                {
                    Message = $"Error: {ex.Message}"
                };
            }
        }

        public async Task<ResponseObject<TModel>> DeleteAsync(TModel entity)
        {
            try
            {
                _context.Set<TModel>().Remove(entity);
                await _context.SaveChangesAsync();

                return new ResponseObject<TModel>
                {
                    Message = $"Success: Delete"
                };
            }
            catch (Exception ex)
            {
                return new ResponseObject<TModel>
                {
                    Message = $"Error: {ex.Message}"
                };
            }
        }
    }
}
