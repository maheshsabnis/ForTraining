using ForTraining.Models;
using ForTraining.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddDbContext<AppDbContext>(options => 
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("AppDbStr"));
});
builder.Services.AddScoped(typeof(GenericService<,>));
//builder.Services.AddScoped<IServies<Category, int>, GenericService<Category, int>>();
//builder.Services.AddScoped<IServies<Product, int>, GenericService<Product, int>>();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
    app.UseSwagger();
    app.UseSwaggerUI();
//}

app.UseHttpsRedirection();


//Minimal API APp

app.MapGet("/api/{entity}", async (string entity, [FromServices] IServiceProvider serviceProvider) =>
{
    var serviceType = GetServiceType(entity);
    dynamic service = serviceProvider.GetService(serviceType);
    var result = await service.GetAsync();
    return Results.Ok(result);
});

app.MapGet("/api/{entity}/{id}", async (string entity, int id, [FromServices] IServiceProvider serviceProvider) =>
{
    var serviceType = GetServiceType(entity);
    dynamic service = serviceProvider.GetService(serviceType);
    var result = await service.GetAsync(id);
    return Results.Ok(result);
});

 

Type GetServiceType(string entity)
{
    return entity.ToLower() switch
    {
        "category" => typeof(GenericService<Category, int>),
        "product" => typeof(GenericService<Product, int>),
        _ => throw new ArgumentException("Invalid entity type")
    };
}

 
 
app.Run();

