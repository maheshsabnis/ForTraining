﻿namespace API_CQRS.Models
{
    public abstract class EntityBase
    {
    }
}
