﻿using System;
using System.Collections.Generic;

namespace API_CQRS.Models;

public partial class Category : EntityBase
{
    public int CategoryRecordId { get; set; }

    public string CategoryId { get; set; } = null!;

    public string CategoryName { get; set; } = null!;

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
