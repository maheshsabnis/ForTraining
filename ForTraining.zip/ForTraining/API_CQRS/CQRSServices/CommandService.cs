﻿using System.ComponentModel;
using API_CQRS.Models;
using API_CQRS.CQRSContracts;

namespace API_CQRS.CQRSServices
{
    public class CommandService : ICommandRequest<Category, int>
    {
        AppDbContext _context;
        ResponseObject<Category> ResponseObject;
        public CommandService(AppDbContext context)
        {
            _context = context;
            ResponseObject = new ResponseObject<Category>();
        }
        async Task<ResponseObject<Category>> ICommandRequest<Category, int>.CreateAsync(Category entity)
        {
            try
            {
                var result = await _context.Categories.AddAsync(entity);
                await _context.SaveChangesAsync();
                ResponseObject.Record = result.Entity;
            }
            catch (Exception ex)
            {
                ResponseObject.Message = ex.Message;
            }
            return ResponseObject;
        }

        Task<ResponseObject<Category>> ICommandRequest<Category, int>.DeleteAsync(int id)
        {
            throw new NotImplementedException();
        }

        Task<ResponseObject<Category>> ICommandRequest<Category, int>.UpdateAsync(int id, Category entity)
        {
            throw new NotImplementedException();
        }
    }
}
