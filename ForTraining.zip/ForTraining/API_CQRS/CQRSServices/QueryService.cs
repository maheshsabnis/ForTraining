﻿using API_CQRS.CQRSContracts;
using API_CQRS.Models;
using Microsoft.EntityFrameworkCore;

namespace API_CQRS.CQRSServices
{
    public class QueryService : IQueryRequest<Category, int>
    {
        private readonly AppDbContext _context;
        private ResponseObject<Category> ResponseObject;
        public QueryService(AppDbContext context)
        {
            _context = context;
            ResponseObject = new ResponseObject<Category>();
        }
        

        async Task<ResponseObject<Category>> IQueryRequest<Category, int>.GetAync(int id)
        {
            if (id == null || id == 0)
            {
                ResponseObject.Records = await _context.Categories.ToListAsync();
            }
            else
            {
                ResponseObject.Record = await _context.Categories.FindAsync(id);
            }
            return ResponseObject;
        }
    }
}
