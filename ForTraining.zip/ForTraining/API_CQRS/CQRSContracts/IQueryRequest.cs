﻿using API_CQRS.Models;

namespace API_CQRS.CQRSContracts
{
    public interface IQueryRequest<TEntity, in TPk> where TEntity: EntityBase
    {
        Task<ResponseObject<TEntity>> GetAync(TPk? id);
    }
}
