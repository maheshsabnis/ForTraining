﻿using API_CQRS.Models;

namespace API_CQRS.CQRSContracts
{
    public interface ICommandRequest<TEntity, in TPk> where TEntity : EntityBase
    {
        Task<ResponseObject<TEntity>> CreateAsync(TEntity entity);
        Task<ResponseObject<TEntity>> UpdateAsync(TPk id, TEntity entity);
        Task<ResponseObject<TEntity>> DeleteAsync(TPk id);
    }
}
