using API_CQRS.CQRSContracts;
using API_CQRS.CQRSServices;
using API_CQRS.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle

builder.Services.AddDbContext<AppDbContext>(options => 
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("AppStr"));
});
builder.Services.AddScoped<IQueryRequest<Category, int>, QueryService>();
builder.Services.AddScoped<ICommandRequest<Category, int>, CommandService>();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.MapGet("/categories", async(IQueryRequest<Category,int> query) => { 
   var response = await query.GetAync(0);
  return Results.Ok(response);
});

app.MapGet("/categories/{id}", async (IQueryRequest<Category, int> query, int id) =>
{
    var response = await query.GetAync(id);
    return Results.Ok(response);
});

app.MapPost("/categories", async (ICommandRequest<Category, int> command, Category category) =>
{
    var response = await command.CreateAsync(category);
    return Results.Ok(response);
});


app.Run();

 