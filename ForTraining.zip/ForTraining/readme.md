# COmmand to build the docker image
docker build -t [TAGNAME] [PATH_TO_DOCKERFILE]]
```bash
docker build -t myapp:v1 .
```
# Command to run the docker image
docker run -p [HOST_PORT]:[CONTAINER_PORT]  [IMAGE-NAME]:[TAGNAME]
```bash
docker run -p 4000:8080 myapp:v1
```

# Command to List all IMages
```bash
docker images
```

# Command to List all Containers
```bash
docker ps -a
```

# COmmand to Push an image to Docker Hub

- CReate a DOcker Hub Account
- Login to Docker Hub
```bash
docker login
```

- Tag the image to the name of the docker hub 
```bash

docker tag [YOUR-IMAGE]:[TAG] [HUB-ACCONT-NAME]/[YOUR-IMAGE]:[TAG]
```
docker tag myapp:v1 mas007/myapp:v1

- Push the image to the docker hub
```bash
docker push [HUB-ACCONT-NAME]/[YOUR-IMAGE]:[TAG]
```
docker push mas007/myapp:v1

# command to pull an image from docker hub
```bash
docker pull [HUB-ACCONT-NAME]/[YOUR-IMAGE]:[TAG]
```

# COmand to STore the Container
```bash
docker STop [CONTAINER-ID] OR [CONTAINER-NAME]
```

# COmmand to Start the COntainer
```bash
docker start [CONTAINER-ID] OR [CONTAINER-NAME]
```


# Command  to remove the container
```bash
docker rm [CONTAINER-ID] OR [CONTAINER-NAME]
```

# Command to remove an image
```bash
docker rmi [IMAGE-ID] OR [IMAGE-NAME]
```


# Microservices Practices
- Single Responsibility Principle
-	THe Microservice to do only a specific type of task
    - E.g. Read is a separate service and write is a seperate service
      - THis leads to Command-Query-Responsibility-Seggrigation (CQRS)
        - Mapper
        - MediatR
- Decentralized Governance
  - A Seperate Management and MOnitoring System for the Microservices App
  - Dedicated Infra
- Decentralized Data Management
  - Seperate Data STore Features
- Design for Failure
  - Resiliency
    - For COntineous failures use the Fallback
- Evolve Services Independently
  - Indipendant changes in the service with new features addition
- Infrastructure Automation
  - CI/CD
  - COntainer, IMages, Networking, LoadBalaner
- Containerization
  - Independent depoyment in separate container
- Service Discovery
  - Available for Public Access
    - Create App Gatewys
    - Single Public address for all services through the gateway  
- Centralized Configuration Management
  - YML and DevOps
- Monitoring
  - PLatform Supported COnfiguration
- Logging
  - By Code or by the platform Configuration
- Tracing
  - By PLatform
- Security
  - User BAsed, ROle Based, Token BAsed, AD
- Continuous Integration and Deployment
  - CI/CD
- Testing
  - Keep the Unit Testing
  - Perfromance, Load, Regresstion Testing
- Documentation
  - Service DOcs
    - Classes
    - Patterns
    - Security
    - Purpose
- API Gateway
  - Easy Service DIscovery
- Circuit Breaker
  - REsiliency with retry and fallback
- Load Balancer
  - Default to Services
    - USed in case of multiple microservices
      - Linked with Public GAteway on One IP Address and different Port 
- Autoscaling
  - COnfguration
- Blue-Green Deployment
  - Deployment Processes
- 